package com.vivekchutke.microservise.checkout.pcfcheckoutservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcfCheckoutServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcfCheckoutServiceApplication.class, args);
	}

}
