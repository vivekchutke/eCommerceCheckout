package com.vivekchutke.microservice.promotion.pcforderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcfOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcfOrderServiceApplication.class, args);
	}

}
